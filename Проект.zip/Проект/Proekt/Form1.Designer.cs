﻿namespace Proekt
{
    partial class Form_Game
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox_EnterNumber = new System.Windows.Forms.TextBox();
            this.label_EnterNumber = new System.Windows.Forms.Label();
            this.button_Exit = new System.Windows.Forms.Button();
            this.button_Reset = new System.Windows.Forms.Button();
            this.label_TryCount = new System.Windows.Forms.Label();
            this.panel = new System.Windows.Forms.Panel();
            this.button_Try = new System.Windows.Forms.Button();
            this.label_WinOrLose = new System.Windows.Forms.Label();
            this.label_Hint = new System.Windows.Forms.Label();
            this.button_Start = new System.Windows.Forms.Button();
            this.listBox_TriedNumbers = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox_EnterNumber
            // 
            this.textBox_EnterNumber.Location = new System.Drawing.Point(6, 26);
            this.textBox_EnterNumber.Name = "textBox_EnterNumber";
            this.textBox_EnterNumber.Size = new System.Drawing.Size(140, 20);
            this.textBox_EnterNumber.TabIndex = 0;
            // 
            // label_EnterNumber
            // 
            this.label_EnterNumber.AutoSize = true;
            this.label_EnterNumber.Location = new System.Drawing.Point(3, 10);
            this.label_EnterNumber.Name = "label_EnterNumber";
            this.label_EnterNumber.Size = new System.Drawing.Size(143, 13);
            this.label_EnterNumber.TabIndex = 1;
            this.label_EnterNumber.Text = "Введите число от 1 до 100:";
            // 
            // button_Exit
            // 
            this.button_Exit.Location = new System.Drawing.Point(231, 211);
            this.button_Exit.Name = "button_Exit";
            this.button_Exit.Size = new System.Drawing.Size(75, 23);
            this.button_Exit.TabIndex = 2;
            this.button_Exit.Text = "&Exit";
            this.button_Exit.UseVisualStyleBackColor = true;
            this.button_Exit.Click += new System.EventHandler(this.button_Exit_Click);
            // 
            // button_Reset
            // 
            this.button_Reset.Location = new System.Drawing.Point(150, 211);
            this.button_Reset.Name = "button_Reset";
            this.button_Reset.Size = new System.Drawing.Size(75, 23);
            this.button_Reset.TabIndex = 3;
            this.button_Reset.Text = "&Reset";
            this.button_Reset.UseVisualStyleBackColor = true;
            this.button_Reset.Click += new System.EventHandler(this.button_Reset_Click);
            // 
            // label_TryCount
            // 
            this.label_TryCount.AutoSize = true;
            this.label_TryCount.Location = new System.Drawing.Point(170, 176);
            this.label_TryCount.Name = "label_TryCount";
            this.label_TryCount.Size = new System.Drawing.Size(124, 13);
            this.label_TryCount.TabIndex = 4;
            this.label_TryCount.Text = "Количество попыток: 0";
            this.label_TryCount.Visible = false;
            // 
            // panel
            // 
            this.panel.Controls.Add(this.label1);
            this.panel.Controls.Add(this.listBox_TriedNumbers);
            this.panel.Controls.Add(this.button_Try);
            this.panel.Controls.Add(this.label_WinOrLose);
            this.panel.Controls.Add(this.label_Hint);
            this.panel.Controls.Add(this.label_EnterNumber);
            this.panel.Controls.Add(this.label_TryCount);
            this.panel.Controls.Add(this.textBox_EnterNumber);
            this.panel.Location = new System.Drawing.Point(12, 12);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(301, 193);
            this.panel.TabIndex = 5;
            // 
            // button_Try
            // 
            this.button_Try.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_Try.Location = new System.Drawing.Point(6, 65);
            this.button_Try.Name = "button_Try";
            this.button_Try.Size = new System.Drawing.Size(144, 108);
            this.button_Try.TabIndex = 7;
            this.button_Try.Text = "Try!";
            this.button_Try.UseVisualStyleBackColor = false;
            this.button_Try.Click += new System.EventHandler(this.button_Try_Click);
            // 
            // label_WinOrLose
            // 
            this.label_WinOrLose.AutoSize = true;
            this.label_WinOrLose.Location = new System.Drawing.Point(3, 185);
            this.label_WinOrLose.Name = "label_WinOrLose";
            this.label_WinOrLose.Size = new System.Drawing.Size(0, 13);
            this.label_WinOrLose.TabIndex = 6;
            // 
            // label_Hint
            // 
            this.label_Hint.AutoSize = true;
            this.label_Hint.Location = new System.Drawing.Point(7, 49);
            this.label_Hint.Name = "label_Hint";
            this.label_Hint.Size = new System.Drawing.Size(66, 13);
            this.label_Hint.TabIndex = 5;
            this.label_Hint.Text = "Подсказка:";
            this.label_Hint.Visible = false;
            // 
            // button_Start
            // 
            this.button_Start.Location = new System.Drawing.Point(18, 211);
            this.button_Start.Name = "button_Start";
            this.button_Start.Size = new System.Drawing.Size(75, 23);
            this.button_Start.TabIndex = 6;
            this.button_Start.Text = "&Start";
            this.button_Start.UseVisualStyleBackColor = true;
            this.button_Start.Click += new System.EventHandler(this.button_Start_Click);
            // 
            // listBox_TriedNumbers
            // 
            this.listBox_TriedNumbers.FormattingEnabled = true;
            this.listBox_TriedNumbers.Location = new System.Drawing.Point(173, 26);
            this.listBox_TriedNumbers.Name = "listBox_TriedNumbers";
            this.listBox_TriedNumbers.Size = new System.Drawing.Size(121, 147);
            this.listBox_TriedNumbers.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(170, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Использованные числа:";
            // 
            // Form_Game
            // 
            this.AcceptButton = this.button_Try;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(318, 242);
            this.Controls.Add(this.button_Start);
            this.Controls.Add(this.panel);
            this.Controls.Add(this.button_Reset);
            this.Controls.Add(this.button_Exit);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form_Game";
            this.Text = "Игра в угадывание числа";
            this.panel.ResumeLayout(false);
            this.panel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_EnterNumber;
        private System.Windows.Forms.Label label_EnterNumber;
        private System.Windows.Forms.Button button_Exit;
        private System.Windows.Forms.Button button_Reset;
        private System.Windows.Forms.Label label_TryCount;
        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.Label label_Hint;
        private System.Windows.Forms.Button button_Start;
        private System.Windows.Forms.Label label_WinOrLose;
        private System.Windows.Forms.Button button_Try;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBox_TriedNumbers;
    }
}

