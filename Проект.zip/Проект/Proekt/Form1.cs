﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proekt
{
    public partial class Form_Game: Form
    {
        Random random = new Random();
        int randomNum;
        int count;
        public Form_Game()
        {
            InitializeComponent();
        }
        private void button_Start_Click(object sender, EventArgs e)
        {
            count = 0;
            GenerateNumber(ref randomNum);
            label_Hint.Visible = true;
            label_TryCount.Visible = true;
        }
        private void button_Try_Click(object sender, EventArgs e)
        {

            if (int.TryParse(textBox_EnterNumber.Text, out int n))
            {
                string biggerOrSmaller = Int32.Parse(textBox_EnterNumber.Text) < randomNum ? "Больше" : "Меньше";
                label_TryCount.Text = $"Количество попыток: {++count}";
                listBox_TriedNumbers.Items.Add($"{textBox_EnterNumber.Text} ({biggerOrSmaller})");

                if (Int32.Parse(textBox_EnterNumber.Text) == randomNum)
                {
                    MessageBox.Show($"Вы выиграли! Загаданным числом было: {randomNum}");
                    Reset();
                }
                else
                    label_Hint.Text = $"Подсказка: {biggerOrSmaller}";
            }
            else
                MessageBox.Show("Введите число!");
        }
        
        private void button_Reset_Click(object sender, EventArgs e)
        {
            Reset();
        }
        private void button_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        void Reset()
        {
            count = 0;
            GenerateNumber(ref randomNum);
            label_Hint.Text = "Подсказка:";
            label_TryCount.Text = "Количество попыток: 0";
            listBox_TriedNumbers.Items.Clear();
        }
        int GenerateNumber(ref int n)
        {
            n = random.Next(1, 100);
            return n;
        }
    }
}
